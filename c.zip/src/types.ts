export type User = {
    id: string,
    name: string,
    email: string,
    password: string,
    login_count: number
}